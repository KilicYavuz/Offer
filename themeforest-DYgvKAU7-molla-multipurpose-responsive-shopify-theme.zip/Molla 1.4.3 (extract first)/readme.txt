Dear customer,

Thank you so much for choose us, to start with Molla, you need

1 - Upload theme file Molla v*.*.*.zip to your Shopify store
2 - Open document folder and check our guide (we will update it every day) or follow from our website: http://the4studio.net/shopify/molla/

If you have any problem, I hope you can send us a email to: the4studio.net@gail.com or our forum: https://support.the4.co/

We will try our best to answer your email / forum as soon as possible, I hope you won't give us bad review.

Thank you for choosing us

Kind Regard
-------------------------------
25/Mar/2020: Updated to version 1.4.3
	- Added: Ask about this product.
	- Added: Age Verification.
	-------------------------------
	Updated details:
		- Added sections/kt_ageVerification.liquid
		- Added sections/kt_askProduct.liquid
		- Added assets/moment-timezone-with-data.min.js
		- Added assets/jquery.currency-shipping.min.js

		- Modified assets/api.jquery.min.js
		- Modified assets/custom.min.js
		- Modified assets/kiti.scss.liquid
		- Modified assets/style-rtl.min.css
		- Modified assets/style.min.css
		- Modified assets/theme.min.js
		- Modified assets/theme_footer_js.js.liquid
		- Modified config/settings_schema.json
		- Modified layout/theme.liquid
		- Modified locales/en.default.json
		- Modified snippets/googleRich.liquid
		- Modified snippets/product-grid-item.liquid
		- Modified snippets/product-layout1.liquid
		- Modified snippets/product-layout2.liquid
		- Modified snippets/product-layout3.liquid
		- Modified snippets/product-layout4.liquid
		- Modified snippets/product-layout5.liquid
		- Modified snippets/product-layout6.liquid
		- Modified snippets/product-layout7.liquid
		- Modified snippets/theme_header_js.liquid
		- Modified templates/product.liquid

-------------------------------
02/Mar/2020: Updated to version 1.4.2
	- Added: Pre order label.
	- Added: German theme language.
	- Fixed: Icon boxed.
	- Fixed: Quickview.
	-------------------------------
	Updated details:
		- Added locales/de.json

		- Modified assets/theme.min.js
		- Modified sections/adminThemeTool.liquid
		- Modified sections/md_icon_boxes.liquid
		- Modified snippets/product-item-flashs.liquid
		- Modified snippets/product-grid-item.liquid
		- Modified snippets/collection-template.liquid
		- Modified snippets/image-grid-item.liquid
		- Modified snippets/kt_logo_header.liquid
		- Modified snippets/meta-tags.liquid
		- Modified sections/search-template.liquid
		- Modified snippets/collection-template.liquid
		- Modified snippets/kt_breadcrumb.liquid
		- Modified snippets/search-bar.liquid
		- Modified templates/product.quickView.liquid

-------------------------------
24/Feb/2020: Updated to version 1.4.1
	- Fixed: Currency.
	- Fixed: Filters.
	- Update: Extensions create product tags.
	-------------------------------
	Updated details:
		- Added templates/cart.t4-import-tags.liquid

		- Modified assets/custom.js
		- Modified assets/jquery.currencies.min.js
		- Modified assets/style-rtl.min.css
		- Modified assets/style.min.css
		- Modified assets/theme.min.js
		- Modified layout/theme.liquid
		- Modified sections/collection-filter.liquid
		- Modified sections/kt_relatedProduct.liquid
		- Modified snippets/kt_cart_popup.liquid
		- Modified snippets/kt_logo_header.liquid

-------------------------------
18/Feb/2020: Updated to version 1.4.0
	- Added: Home Extreme Sport.
	- Added: Calculate Free Shipping Threshold in cart page.
	- Added: 2 Banner layout.
	- Fixed: Currency.
	- Fixed: Video slide item.
	- Fixed: Product 360.
	-------------------------------
	Updated details:
		- Added sections/md_banner_template_6.liquid
		- Added snippets/header-18.liquid

		- Modified assets/api.jquery.min.js
		- Modified assets/custom.min.js
		- Modified assets/jquery.currencies.min.js
		- Modified assets/kiti.scss.liquid
		- Modified assets/settings_preset.json
		- Modified assets/style-rtl.min.css
		- Modified assets/style.min.css
		- Modified assets/theme.min.js
		- Modified assets/theme_footer_js.js.liquid
		- Modified assets/threesixty.min.css
		- Modified assets/threesixty.min.js
		- Modified config/settings_schema.json
		- Modified snippets/kt_product_tabs.liquid
-------------------------------
07/Feb/2020: Updated to version 1.3.2
	- Added: Product configuration.
	- Fixed: Currency.
	- Fixed: Wishlist.
	-------------------------------
	Updated details:
		- Modified assets/theme.min.js
		- Modified assets/customize.min.js

		- Added layout/theme.prd-additional.liquid
		- Added templates/page.prd-additional.liquid

-------------------------------
01/Feb/2020: Updated to version 1.3.1
	- Added: Payment images.
	- Added: Tooltip of swatch.
	- Modified: Auto Currency.
	- Fixed: Subscribe form.
	-------------------------------
	Updated details:
		- Modified assets/jquery.currencies.min.js
		- Modified assets/ktTools.slideshow.js.liquid
		- Modified assets/site.webmanifest.json.liquid
		- Modified assets/style-rtl.min.css
		- Modified assets/style.min.css
		- Modified assets/theme.min.js
		- Modified assets/theme_footer_js.js.liquid
		- Modified assets/vendor.js
		- Modified config/settings_schema.json
		- Modified layout/theme.liquid
		- Modified sections/about-template.liquid
		- Modified sections/collection-filter.liquid
		- Modified sections/footer_01.liquid
		- Modified sections/footer_02.liquid
		- Modified sections/footer_03.liquid
		- Modified sections/footer_04.liquid
		- Modified sections/footer_06.liquid
		- Modified sections/footer_07.liquid
		- Modified sections/kt_relatedProduct.liquid
		- Modified sections/kt_slideshow.liquid
		- Modified sections/product-template.liquid
		- Modified snippets/kt_currency_widget.liquid
		- Modified snippets/kt_logo_header.liquid
		- Modified snippets/kt_mini-cart.liquid
		- Modified snippets/kt_newsletter_form.liquid
		- Modified snippets/kt_product_images.liquid
		- Modified snippets/kt_product_tabs.liquid
		- Modified snippets/kt_variants_options.liquid
		- Modified snippets/product-layout1.liquid
		- Modified snippets/product-layout2.liquid
		- Modified snippets/product-layout3.liquid
		- Modified snippets/product-layout4.liquid
		- Modified snippets/product-layout5.liquid
		- Modified snippets/product-layout6.liquid
		- Modified snippets/product-layout7.liquid
		- Modified snippets/styleSpeed.liquid
		- Modified snippets/theme_header_js.liquid
		- Modified templates/cart.liquid
		- Modified templates/cart.workerktlz.liquid
		- Modified templates/product.quickView.liquid
		- Modified templates/search.liquid

		- Added assets/jquery-3.4.1.min.js
		- Added assets/jquery.datetimepicker.full.min.js
		- Added assets/jquery.datetimepicker.min.css
		- Added layout/theme.prd-additional.liquid
		- Added templates/collection.count_with_tag.liquid
		- Added templates/page.prd-additional.liquid
		- Added templates/search.prd-additional.liquid

-------------------------------
13/Jan/2020: Updated to version 1.3.0
	- Added Homepage 23
	- Added Cart popup
	- Support Ryviu, Alireview, Loox...
	- Fixed Some small errors
	-------------------------------
	Updated details:
	    - Added sections/footer_07.liquid
	    - Added sections/kt_relatedProducts_cartPopup.liquid
	    - Added sections/md_brand_2.liquid
	    - Added sections/md_product_section_show_banner_2.liquid
	    - Added sections/newsletter-popup-2.liquid
	    - Added snippets/header-17.liquid
	    - Added snippets/kt_cart_popup.liquid
	    - Added snippets/t4-pcc.liquid
	    - Added templates/cart.listjsonpopup.liquid

	    - Modified assets/api.jquery.min.js
	    - Modified assets/custom.min.js
	    - Modified assets/kiti.scss.liquid
	    - Modified assets/settings_preset.json
	    - Modified assets/style-rtl.min.css
	    - Modified assets/style.min.css
	    - Modified assets/swatch-color.css
	    - Modified assets/theme.min.js
	    - Modified assets/theme_footer_js.js.liquid
	    - Modified assets/vendor.js

	    - Modified config/settings_schema.json

	    - Modified layout/theme.liquid
	    - Modified locales/en.default.json

	    - Modified sections/adminThemeTool.liquid
	    - Modified sections/cart-template.liquid
	    - Modified sections/header.liquid
	    - Modified sections/kt_relatedProduct.liquid
	    - Modified sections/kt_relatedProduct_sidebar.liquid
	    - Modified sections/kt_slideshow.liquid
	    - Modified sections/kt_top_banner.liquid
	    - Modified sections/md_banner_products_set_4.liquid
	    - Modified snippets/image-grid-item.liquid
	    - Modified snippets/kt_mini-cart.liquid
	    - Modified snippets/kt_reviewProduct.liquid
	    - Modified snippets/rating_star.liquid
	    - Modified snippets/theme_header_js.liquid
-------------------------------
02/Jan/2020: Updated to version 1.2.2
	- Added login/register modal
	- Move "Update shipping rates" button to theme action list
	- Fixed Some small errors
	-------------------------------
	Updated details:
	    - Added snippets/account-popup.liquid
            - Added templates/cart.account-modal.liquid
            - Added templates/cart.mobile-menu.liquid
            
            - Replace assets/ { site.webmanifest.liquid → site.webmanifest.json.liquid }

            - Modified assets/adminThemeTool.scss
            - Modified assets/custom.js
            - Modified assets/custom.min.js
            - Modified assets/jquery.currencies.js
            - Modified assets/kiti.scss.liquid
            - Modified assets/style-rtl.css
            - Modified assets/style-rtl.min.css
            - Modified assets/style.css
            - Modified assets/style.min.css
            - Modified assets/theme-rtl.scss
            - Modified assets/theme.js
            - Modified assets/theme.min.js
            - Modified assets/theme.scss
            - Modified assets/theme_footer_js.js.liquid
            - Modified config/settings_schema.json
            - Modified layout/theme.liquid
            - Modified locales/en.default.json
            - Modified sections/adminThemeTool.liquid
            - Modified sections/cart-template.liquid
            - Modified sections/collection-filter.liquid
            - Modified sections/footer_01.liquid
            - Modified sections/footer_02.liquid
            - Modified sections/footer_03.liquid
            - Modified sections/footer_04.liquid
            - Modified sections/footer_05.liquid
            - Modified sections/footer_06.liquid
            - Modified sections/header-mobile.liquid
            - Modified sections/kt_slideshow.liquid
            - Modified sections/newsletter-popup.liquid
            - Modified snippets/kt_cart_drawer.liquid
            - Modified snippets/kt_currency_widget.liquid
            - Modified snippets/kt_section_space.liquid
            - Modified snippets/meta-tags.liquid
            - Modified snippets/product-item-flashs.liquid
            - Modified snippets/product-list-item-mini2.liquid
            - Modified snippets/styleSpeed.liquid
            - Modified snippets/theme_header_js.liquid

            - Deleted assets/bt_placeholder.svg.liquid
            - Deleted assets/kt_bg.png
            - Deleted assets/test-parallax.js
            - Deleted assets/theme.min.css
            - Deleted assets/view_icon.eot
            - Deleted assets/view_icon.svg
            - Deleted assets/view_icon.ttf
            - Deleted assets/view_icon.woff
            - Deleted snippets/kt_inAdmin_section.liquid
            - Deleted snippets/shortcode-kt_lookbook.liquid
-----------------------------------

21/Dec/2019: Updated to version 1.2.1
	- Added RTL layout
	- Added Multi currency by Shopify
	- Fixed Newsletter popup
	-------------------------------
	Updated details:
		- Added assets/style-rtl.css
		- Added assets/style-rtl.min.css
		- Added assets/theme-rtl.scss
		
		- Modified assets/custom.js
		- Modified assets/custom.min.js
		- Modified assets/jquery.currencies.js
		- Modified assets/jquery.currencies.min.js
		- Modified assets/kiti.scss.liquid
		- Modified assets/settings_preset.json
		- Modified assets/style.css
		- Modified assets/style.min.css
		- Modified assets/theme.js
		- Modified assets/theme.min.js
		- Modified assets/theme.scss
		- Modified assets/theme_footer_js.js.liquid

		- Modified layout/theme.liquid

		- Modified sections/adminThemeTool.liquid
		- Modified sections/article-template-fullwidth.liquid
		- Modified sections/article-template-fullwitdh-sidebar.liquid
		- Modified sections/contact-template.liquid
		- Modified sections/footer_03.liquid
		- Modified sections/header.liquid
		- Modified sections/kt_recentlyViewedProducts.liquid
		- Modified sections/kt_slideshow.liquid
		- Modified sections/kt_slideshowSimple.liquid
		- Modified sections/kt_slideshowSimpleBanner.liquid
		- Modified sections/kt_top_banner.liquid
		- Modified sections/md-collection-banners-box.liquid
		- Modified sections/md-collection-brand.liquid
		- Modified sections/md-collection-list_item_cattegories.liquid
		- Modified sections/md-collection-product_section_slide.liquid
		- Modified sections/md_accordions.liquid
		- Modified sections/md_banner_products_set.liquid
		- Modified sections/md_banner_products_set_2.liquid
		- Modified sections/md_banner_products_set_3.liquid
		- Modified sections/md_banner_products_set_4.liquid
		- Modified sections/md_banner_template_1.liquid
		- Modified sections/md_banner_template_2.liquid
		- Modified sections/md_banner_template_3.liquid
		- Modified sections/md_banner_template_4.liquid
		- Modified sections/md_banner_template_5.liquid
		- Modified sections/md_blog.liquid
		- Modified sections/md_brand.liquid
		- Modified sections/md_call_to_action.liquid
		- Modified sections/md_call_to_action_2.liquid
		- Modified sections/md_countdown_section_with_products_1.liquid
		- Modified sections/md_countdown_section_with_products_2.liquid
		- Modified sections/md_icon_boxes.liquid
		- Modified sections/md_list_item_cattegories_1.liquid
		- Modified sections/md_list_item_cattegories_2.liquid
		- Modified sections/md_lookbook_1.liquid
		- Modified sections/md_portfolio.liquid
		- Modified sections/md_product_section_show.liquid
		- Modified sections/md_product_section_show_banner_1.liquid
		- Modified sections/md_product_section_slide.liquid
		- Modified sections/md_product_section_slide_2.liquid
		- Modified sections/md_product_section_slide_banner_1.liquid
		- Modified sections/md_product_section_tab_slide.liquid
		- Modified sections/md_product_section_tab_slide_2.liquid
		- Modified sections/md_product_section_tab_slide_banner.liquid
		- Modified sections/md_product_section_tab_slide_banner_2.liquid
		- Modified sections/md_socials_and_customers_say.liquid
		- Modified sections/md_tabs.liquid
		- Modified sections/md_testimonials.liquid
		- Modified sections/newsletter-popup.liquid
		- Modified sections/order-template.liquid
		- Modified sections/product-template.liquid

		- Modified snippets/header-01.liquid
		- Modified snippets/header-05.liquid
		- Modified snippets/header-06.liquid
		- Modified snippets/header-07.liquid
		- Modified snippets/header-12.liquid
		- Modified snippets/header-13.liquid
		- Modified snippets/header-14.liquid
		- Modified snippets/kt_breadcrumb.liquid
		- Modified snippets/kt_currency_widget.liquid
		- Modified snippets/kt_gridlist_layout.liquid
		- Modified snippets/kt_header-top.liquid
		- Modified snippets/kt_mini-cart.liquid
		- Modified snippets/kt_reviewProduct.liquid
		- Modified snippets/kt_section_space.liquid
		- Modified snippets/meta-tags.liquid
		- Modified snippets/pagination.liquid
		- Modified snippets/product-layout1.liquid
		- Modified snippets/product-layout2.liquid
		- Modified snippets/product-layout3.liquid
		- Modified snippets/product-layout5.liquid
		- Modified snippets/product-layout6.liquid
		- Modified snippets/product-layout7.liquid
		- Modified snippets/styleSpeed.liquid
		- Modified snippets/theme_header_js.liquid

		- Modified templates/cart.listjson.liquid
		- Modified templates/collection.compare.liquid
		- Modified templates/product.quickView.liquid
	-------------------------------

16/Dec/2019: Updated to version 1.2.0
	- Added Home page 22(Tools)
	- Fixed Some small issue
	-------------------------------
	Updated details:
		- Modified assets/custom.js
		- Modified assets/style.min.css
		- Modified assets/theme.js
		- Modified assets/theme.scss
		- Modified locales/en.default.json
		- Modified sections/about-template.liquid
		- Modified sections/header.liquid
		- Modified sections/kt_slideshow.liquid
		- Modified sections/login-register-template.liquid
		- Modified sections/product-template.liquid
		- Modified snippets/collection-template.liquid
		- Modified snippets/kt_blog_sidebar.liquid
		- Modified snippets/kt_button_has_variant.liquid
		- Modified snippets/product-layout1.liquid
		- Modified snippets/product-layout2.liquid
		- Modified snippets/product-layout3.liquid
		- Modified snippets/product-layout7.liquid
		- Modified snippets/product-list-item.liquid
	-------------------------------

09/Dec/2019: Updated to version 1.1.0
	- Added Home page 21(Sport)
	- Added Header 16
	- Added 4 new section(instagram, categories, products)
	- Fixed Suggest products
	- Fixed Unable to load variants
	-------------------------------
	Updated details:
		- Added assets/product.related.liquid
		- Added sections/kt_instagram_3.liquid
		- Added sections/md_banner_products_set_4.liquid
		- Added sections/md_list_item_cattegories_2.liquid
		- Added sections/md_product_section_tab_banner.liquid
		- Added snippets/header-16.liquid
		- Added snippets/kt_suggest.liquid
		- Added templates/product.recently-sidebar.liquid

		- Modified assets/custom.js
		- Modified assets/custom.min.js
		- Modified assets/kiti.scss.liquid
		- Modified assets/settings_preset.json
		- Modified assets/style.css
		- Modified assets/style.min.css
		- Modified assets/swatch-color.css
		- Modified assets/theme.js
		- Modified assets/theme.min.js
		- Modified assets/theme.scss
		- Modified assets/theme_footer_js.js.liquid
		- Modified config/settings_schema.json
		- Modified layout/theme.liquid
		- Modified locales/en.default.json
		- Modified sections/adminThemeTool.liquid
		- Modified sections/cart-template.liquid
		- Modified sections/collection-filter.liquid
		- Modified sections/header-mobile.liquid
		- Modified sections/header.liquid
		- Modified sections/kt_slideshow.liquid
		- Modified sections/kt_top_banner.liquid
		- Modified sections/kt_vertical-menu-0.liquid
		- Modified sections/kt_vertical-menu-1.liquid
		- Modified sections/kt_vertical-menu-2.liquid
		- Modified sections/kt_vertical-menu-3.liquid
		- Modified sections/kt_vertical-menu-4.liquid
		- Modified sections/kt_vertical-menu-5.liquid
		- Modified sections/kt_vertical-menu-6.liquid
		- Modified sections/kt_vertical-menu-7.liquid
		- Modified sections/kt_vertical-menu-8.liquid
		- Modified sections/kt_vertical-menu-9.liquid
		- Modified sections/list-collections-template.liquid
		- Modified sections/md_banner_products_set_2.liquid
		- Modified sections/md_banner_template_5.liquid
		- Modified sections/md_blog.liquid
		- Modified sections/md_call_to_action.liquid
		- Modified sections/md_countdown_section_1.liquid
		- Modified sections/md_countdown_section_2.liquid
		- Modified sections/md_countdown_section_with_banner_1.liquid
		- Modified sections/md_countdown_section_with_products_1.liquid
		- Modified sections/md_countdown_section_with_products_2.liquid
		- Modified sections/md_list_item_cattegories_1.liquid
		- Modified sections/md_portfolio.liquid
		- Modified sections/md_product_section_show.liquid
		- Modified sections/md_product_section_show_3.liquid
		- Modified sections/md_product_section_show_banner_1.liquid
		- Modified sections/md_product_section_slide_banner_1.liquid
		- Modified sections/md_product_section_tab_load.liquid
		- Modified sections/md_product_section_tab_load_2.liquid
		- Modified sections/password-content.liquid
		- Modified sections/product-template.liquid
		- Modified snippets/collection-template.liquid
		- Modified snippets/header-01.liquid
		- Modified snippets/header-02.liquid
		- Modified snippets/header-03.liquid
		- Modified snippets/header-04.liquid
		- Modified snippets/header-05.liquid
		- Modified snippets/header-07.liquid
		- Modified snippets/header-08.liquid
		- Modified snippets/header-09.liquid
		- Modified snippets/header-10.liquid
		- Modified snippets/header-11.liquid
		- Modified snippets/header-12.liquid
		- Modified snippets/header-13.liquid
		- Modified snippets/header-14.liquid
		- Modified snippets/header-15.liquid
		- Modified snippets/kt_cart_drawer.liquid
		- Modified snippets/kt_filter_sortby.liquid
		- Modified snippets/kt_gridlist_layout.liquid
		- Modified snippets/kt_header-top.liquid
		- Modified snippets/kt_mini-cart.liquid
		- Modified snippets/product-grid-item.liquid
		- Modified snippets/product-layout1.liquid
		- Modified snippets/product-layout2.liquid
		- Modified snippets/product-layout3.liquid
		- Modified snippets/product-layout4.liquid
		- Modified snippets/product-layout5.liquid
		- Modified snippets/product-layout6.liquid
		- Modified snippets/product-layout7.liquid
		- Modified snippets/search-bar.liquid
		- Modified snippets/styleSpeed.liquid
		- Modified snippets/theme_header_js.liquid
		- Modified templates/blog.articlesAjax.liquid
		- Modified templates/cart.workerktlz.liquid
		- Modified templates/collection.productsAjax.liquid
		- Modified templates/collection.test.liquid
		- Modified templates/gift_card.liquid
		- Modified templates/page.vertical-menu.liquid
		- Modified templates/product.jsfull.liquid
		- Modified templates/product.quickView.liquid
	-------------------------------

27/Nov/2019: Updated to version 1.0.1
	- Added Unit prices (Available only to merchants in Germany and France.)
	- Fixed Predictive search
	- Fixed Unable to load variants
	- Fixed Header style 5
	-------------------------------
	Updated details:
		- Modified assets/api.jquery.js
		- Modified assets/api.jquery.min.js
		- Modified assets/custom.js
		- Modified assets/custom.min.js
		- Modified assets/settings_preset.json
		- Modified assets/style.css
		- Modified assets/style.min.css
		- Modified assets/theme.js
		- Modified assets/theme.min.js
		- Modified assets/theme.scss
		- Modified config.yml
		- Modified config/settings_schema.json
		- Modified locales/en.default.json
		- Modified locales/vi.json
		- Modified sections/adminThemeTool.liquid
		- Modified sections/kt_slideshow.liquid
		- Modified sections/md_banner_template_1.liquid
		- Modified sections/md_product_section_show.liquid
		- Modified sections/md_product_section_show_banner_1.liquid
		- Modified sections/md_product_section_tab_load.liquid
		- Modified sections/md_product_section_tab_load_2.liquid
		- Modified sections/product-template.liquid
		- Modified snippets/header-05.liquid
		- Modified snippets/kt-currency-name.liquid
		- Modified snippets/kt_currency_widget.liquid
		- Modified snippets/product-grid-item.liquid
		- Modified snippets/product-item-prices.liquid
		- Modified snippets/product-layout1.liquid
		- Modified snippets/product-layout2.liquid
		- Modified snippets/product-layout3.liquid
		- Modified snippets/product-layout4.liquid
		- Modified snippets/product-layout5.liquid
		- Modified snippets/product-layout6.liquid
		- Modified snippets/product-layout7.liquid
		- Modified templates/cart.listjson.liquid
		- Modified templates/cart.listjsondrop.liquid
	-------------------------------
21/Nov/2019: Released version 1.0.0
	- You need read instruction in documentation folder